package com.example.estudo_books.model;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.estudo_books.listeners.LoginListener;
import com.example.estudo_books.listeners.livroListener;
import com.example.estudo_books.listeners.livrosListener;
import com.example.estudo_books.utils.LivrosJsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SingletonLivros {

    private static RequestQueue volleyQueue = null;
    private static SingletonLivros INSTANCE = null;

    private livroListener livroListener;
    private livrosListener livrosListener;

    private LoginListener loginListener;

    private String TOKEN ="AMSI26token-NOTICIA";
    private  final String UrlAPILivros ="http://amsi.dei.estg.ipleiria.pt/api/livros";
    private  final String UrlAPILogin="http://amsi.dei.estg.ipleiria.pt/api";

    private ArrayList<Livro> livros;

    public static synchronized SingletonLivros getInstance(Context context) {
        if(INSTANCE == null){
            INSTANCE = new SingletonLivros(context);
            volleyQueue = Volley.newRequestQueue(context);
        }
        return INSTANCE;
    }

    private SingletonLivros(Context context) {
        livros = new ArrayList<>();

    }

    public void setLivroListener(livroListener livroListener) {
        this.livroListener = livroListener;
    }

    public void setLivrosListener(livrosListener livrosListener) {
        this.livrosListener = livrosListener;
    }
    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }

    public Livro getLivro(int id) {
        for (Livro n : livros) {
            if (n.getId() == id) {
                return n;
            }
        }
        return null;
    }

    public void LoginAPI(final String email, final String Pass){
        JSONObject jsonParams = new JSONObject();
        try {
            jsonParams.put("email", email);
            jsonParams.put("password", Pass);

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST, UrlAPILogin, jsonParams,
                response -> {
                    String token = LivrosJsonParser.parserJsonLogin(response);
                    if (loginListener!= null){
                        loginListener.onValidateLogin(token, email);
                    }
                },

                volleyError -> {
                    loginListener.onError();
                });

        volleyQueue.add(request);
    }

    public void getAllLivrosAPI(final Context context){
        if (!LivrosJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
            if (livrosListener != null)
                livrosListener.onRefresh(livros);
        } else {
            JsonArrayRequest request = new JsonArrayRequest(
                    Request.Method.GET, UrlAPILivros, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray jsonArray) {
                    livros = LivrosJsonParser.parserJsonLivros(jsonArray);
                    if (livrosListener != null)
                        livrosListener.onRefresh(livros);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Toast.makeText(context, volleyError.getMessage(), Toast.LENGTH_LONG).show();

                }
            });
            volleyQueue.add(request);
        }
    }

    public void editarLivroAPI(final Livro livro, final Context context){
        if (!LivrosJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest request = new StringRequest(
                    Request.Method.PUT, UrlAPILivros + "/" + livro.getId(), new Response.Listener<String>() {
                @Override
                public void onResponse(String s) {
                    if (livroListener != null)
                        livroListener.onRefreshDetalhes();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Toast.makeText(context, volleyError.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("token", TOKEN);
                    params.put("titulo", livro.getTitulo());
                    params.put("serie", livro.getSerie());
                    params.put("autor", livro.getAutor());
                    params.put("ano", livro.getAno() + "");
                    params.put("capa", livro.getCapa());
                    return params;
                }
            };
            volleyQueue.add(request);
        }
    }

    public void adicionarLivroAPI(final Livro livro, final Context context) {
        //Verifica internet
        if (!LivrosJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            //Faz POST para API
            StringRequest req = new StringRequest(Request.Method.POST, UrlAPILivros, new Response.Listener<String>() {

                @Override
                public void onResponse(String s) {
                    if (livroListener != null)
                        //Avisa Activity de detalhes
                        livroListener.onRefreshDetalhes();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Toast.makeText(context, volleyError.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                //Envia dados do livro + token
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("token", TOKEN);
                    params.put("titulo", livro.getTitulo());
                    params.put("serie", livro.getSerie());
                    params.put("autor", livro.getAutor());
                    params.put("ano", livro.getAno() + "");
                    params.put("capa", livro.getCapa());
                    return params;
                }
            };
            volleyQueue.add(req);
        }
    }

    public void removerLivroAPI(final Livro livro, final Context context){
        if (!LivrosJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest request = new StringRequest(
                    Request.Method.DELETE, UrlAPILivros + "/" + livro.getId(),
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String s) {
                            if (livroListener != null)
                                livroListener.onRefreshDetalhes();
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    Toast.makeText(context, volleyError.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
