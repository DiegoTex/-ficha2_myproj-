package com.example.estudo_books.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.estudo_books.R;
import com.example.estudo_books.model.Livro;

import java.util.ArrayList;

public class ListaLivrosAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;

    //lista de livros que veio da API
    public ArrayList<Livro> livros;

    public ListaLivrosAdapter(Context context, ArrayList<Livro> livros){
        this.context = context;
        this.livros = livros;
    }

    @Override
    public int getCount() {
        return livros.size();
    }

    @Override
    public Object getItem(int position) {
        return livros.get(position);
    }

    @Override
    public long getItemId(int position) {
        return livros.get(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        if (inflater==null)
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //Cria se nao tiver nenhum a partir do item
        if(view==null)
            view=inflater.inflate(R.layout.item_lista_livro, null);

        /*Otimizaçao - reutilizar o layout em vez de estar sempre a criar novo*/
        ViewHolderList viewHolder = (ViewHolderList) view.getTag();

        //Se for null cria um novo
        if(viewHolder==null){
            viewHolder=new ViewHolderList(view);
            view.setTag(viewHolder);
        }

        //Se nao so atualiza os dados para reutilizar a view
        viewHolder.update(livros.get(position));
        return view;
    }

    //Classe dentro da classe que define os componentes da view
    private class ViewHolderList{
        private TextView tvTitulo, tvSerie, tvAutor, tvAno;
        private ImageView ivCapa;

        public ViewHolderList(View view){
            tvTitulo = view.findViewById(R.id.tvTitulo);
            tvSerie = view.findViewById(R.id.tvSerie);
            tvAutor = view.findViewById(R.id.tvAutor);
            tvAno = view.findViewById(R.id.tvAno);
            ivCapa = view.findViewById(R.id.ivCapa);
        }

        public void update(Livro livro){
            tvTitulo.setText(livro.getTitulo());
            tvSerie.setText(livro.getSerie());
            tvAutor.setText(livro.getAutor());
            tvAno.setText(livro.getAno() + "");
            //ivCapa.setImageResource(livro.getCapa());
            Glide.with(context)
                    .load(livro.getCapa())
                    .placeholder(R.drawable.logoipl)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(ivCapa);

        }
    }
}
