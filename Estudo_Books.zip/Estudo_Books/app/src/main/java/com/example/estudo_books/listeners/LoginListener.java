package com.example.estudo_books.listeners;

public interface LoginListener {
    void onValidateLogin(final String token, final String email);

    void onError();

}
