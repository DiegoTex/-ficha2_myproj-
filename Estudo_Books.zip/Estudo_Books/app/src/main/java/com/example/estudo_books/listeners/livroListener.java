package com.example.estudo_books.listeners;

public interface livroListener {
    void onRefreshDetalhes();
}
