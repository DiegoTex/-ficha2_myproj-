package com.example.estudo_books.model;

public class Livro {
    // private static  int autoincrementId = 1;
    private int id, ano;
    private String titulo, serie, autor, capa;

    // CONSTRUTOR COM TODOS OS ATRIBUTOS
    public Livro(int id, String capa, int ano, String titulo, String serie, String autor){
        this.id = id;
        this.capa = capa;
        this.ano = ano;
        this.titulo = titulo;
        this.serie = serie;
        this.autor = autor;
    }
    // GETTERS
    public int getId() { return id; }
    public int setId(int id){return this.id = id;}
    public String getTitulo() { return titulo; }
    public String getSerie() { return serie; }
    public String getAutor() { return autor; }
    public int getAno() { return ano; }
    public String getCapa() { return capa; }

    // SETTERS (EXCETO ID)
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setSerie(String serie) { this.serie = serie; }
    public void setAutor(String autor) { this.autor = autor; }
    public void setAno(int ano) { this.ano = ano; }
    public void setCapa(String capa) { this.capa = capa; }
}
