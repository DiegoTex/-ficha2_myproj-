package com.example.estudo_books.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.example.estudo_books.model.Livro;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LivrosJsonParser {
    public static boolean isConnectionInternet(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    public static String parserJsonLogin(JSONObject response){
        String token = null;

        try {
            token = response.getString("token");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return token;
    }

    public static ArrayList<Livro> parserJsonLivros(JSONArray response){
        ArrayList<Livro> livros = new ArrayList<>();

        //Percorrer todos os objetos JSON
        for (int i = 0; i < response.length(); i++){
            try{
                //Cada posição é um livro em formato JSON
                JSONObject livro = (JSONObject) response.get(i);

                //Extrair campos do JSON
                int id = livro.getInt("id");
                String titulo = livro.getString("titulo");
                String serie =livro.getString("serie");
                String autor = livro.getString("autor");
                int ano = livro.getInt("ano");
                String capa = livro.getString("capa");

                //Criar objeto Livro
                Livro auxLivro = new Livro(id, capa, ano, titulo, serie, autor);

                //Adicionar à lista
                livros.add(auxLivro);

            } catch (JSONException e){
                throw new RuntimeException(e);
            }
        }
        return livros;
    }


}
