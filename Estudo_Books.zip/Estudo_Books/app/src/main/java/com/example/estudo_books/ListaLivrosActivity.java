package com.example.estudo_books;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.estudo_books.Adapters.ListaLivrosAdapter;
import com.example.estudo_books.listeners.livrosListener;
import com.example.estudo_books.model.Livro;
import com.example.estudo_books.model.SingletonLivros;

import java.util.ArrayList;

public class ListaLivrosActivity extends AppCompatActivity implements livrosListener {

    ArrayList<Livro> livros;

    SingletonLivros DataManager;

    ListView lvLivros;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_livros);

        lvLivros = findViewById(R.id.lvLivros);


        DataManager = SingletonLivros.getInstance(this);

        DataManager.setLivrosListener(this);
        DataManager.getAllLivrosAPI(this);

        lvLivros.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Livro livroSelecionado = livros.get(position);

                //Se clicar num item (livro) vou para o DetalhesActivity => envio o ID do livro selecionado
                Intent intent= new Intent(ListaLivrosActivity.this, DetalhesLivroActivity.class);
                intent.putExtra("IDLivro", /* Esta a vir como "long" ms do outro lado é int */livroSelecionado.getId());
                startActivity(intent);
            }
        });


    }

    @Override
    public void onRefresh(ArrayList<Livro> livros) {
        if (livros != null) {
            lvLivros.setAdapter(new ListaLivrosAdapter(this, livros));
        }
    }
}