package com.example.estudo_books.listeners;

import com.example.estudo_books.model.Livro;

import java.util.ArrayList;

public interface livrosListener {

    void onRefresh(ArrayList<Livro> livros);
}
