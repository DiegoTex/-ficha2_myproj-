package com.example.estudo_books;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.estudo_books.listeners.livroListener;
import com.example.estudo_books.model.Livro;
import com.example.estudo_books.model.SingletonLivros;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DetalhesLivroActivity extends AppCompatActivity implements livroListener {

    EditText etTitulo, etSerie, etAutor, etAno;
    ImageView ivCapa;
    FloatingActionButton fabGuardar;

    private Livro livro;
    SingletonLivros manager;

    public static final String DEFAULT_IMG =
            "http://amsi.dei.estg.ipleiria.pt/img/ipl_semfundo.png";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalhes_livro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        manager = SingletonLivros.getInstance(this);
        manager.setLivroListener(this);

        int id = getIntent().getIntExtra("IDLivro", -1);

        if (id != -1) {
            livro = manager.getLivro(id);
        }

        etTitulo=findViewById(R.id.etTitulo);
        etSerie=findViewById(R.id.etSerie);
        etAutor=findViewById(R.id.etAutor);
        etAno=findViewById(R.id.etAno);
        ivCapa=findViewById(R.id.ivCapa);
        fabGuardar=findViewById(R.id.fabGuardar);

        if(livro!=null) {
            setTitle(livro.getTitulo());
            carregarLivro();
        } else {
            setTitle("Adicionar Livro");
            fabGuardar.setImageResource(R.drawable.ic_action_add); // Se nao existe muda o icone
        }

        fabGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLivroValido()){
                    if (livro != null) {
                        livro.setTitulo(etTitulo.getText().toString());
                        livro.setAutor(etAutor.getText().toString());
                        livro.setSerie(etSerie.getText().toString());
                        livro.setAno(Integer.parseInt(etAno.getText().toString()));
                        manager.editarLivroAPI(livro, DetalhesLivroActivity.this);
                    } else { //Se nao existe, cria um novo livro
                        livro = new Livro(0, DEFAULT_IMG,
                                Integer.parseInt(etAno.getText().toString()),
                                etTitulo.getText().toString(),
                                etSerie.getText().toString(),
                                etAutor.getText().toString());
                        manager.adicionarLivroAPI(livro, DetalhesLivroActivity.this);
                    }
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (livro!=null)
            getMenuInflater().inflate(R.menu.menu_remove,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itemRemover){
            dialogRemover();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void dialogRemover(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Remover livro")
                .setMessage("Tem certeza que deseja remover o livro?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        manager.removerLivroAPI(livro, DetalhesLivroActivity.this);
                        finish();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        // Não acontece nada
                    }
                })
                .setIcon(android.R.drawable.ic_delete)
                .show();
    }

    private boolean isLivroValido(){
        String titulo = etTitulo.getText().toString();
        String serie = etSerie.getText().toString();
        String autor = etAutor.getText().toString();
        String ano = etAno.getText().toString();
        int auxAno;
        if (titulo.length()<3 || serie.length()<3 || autor.length()<3)
            return false;
        if (ano.length()!=4)
            return false;

        try {
            auxAno=Integer.parseInt(ano);
        } catch (NumberFormatException e) {
            return false;
            //throw new RuntimeException(e);
        }
        return true;
    }

    private void carregarLivro() {
        setTitle("Detalhes: "+ livro.getTitulo());
        etTitulo.setText(livro.getTitulo());
        etSerie.setText(livro.getSerie());
        etAutor.setText(livro.getAutor());
        etAno.setText(livro.getAno()+"");
        //ivCapa.setImageResource(livro.getCapa());
        Glide.with(this)
                .load(livro.getCapa())
                .placeholder(R.drawable.logoipl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(ivCapa);
    }

    @Override
    public void onRefreshDetalhes() {
        finish();
    }
}