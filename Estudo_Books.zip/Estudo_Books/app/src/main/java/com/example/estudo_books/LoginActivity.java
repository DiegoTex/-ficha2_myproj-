package com.example.estudo_books;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.estudo_books.listeners.LoginListener;
import com.example.estudo_books.model.SingletonLivros;

public class LoginActivity extends AppCompatActivity implements LoginListener {

    CheckBox cbLembrar;
    EditText etUser, etPass;
    Button button;

    SingletonLivros DataManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_main);

        DataManager = SingletonLivros.getInstance(this);

        cbLembrar = findViewById(R.id.cbLembrar);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        button = findViewById(R.id.button);

        button.setOnClickListener(v -> {
            String email = etUser.getText().toString();
            String pass = etPass.getText().toString();

            if (!isEmailValido(email)){
                Toast.makeText(this, "Email invalido", Toast.LENGTH_SHORT).show();
            }
            if (!isPasswordValida(pass)){
                Toast.makeText(this, "Password invalida", Toast.LENGTH_SHORT).show();
            }
            if (cbLembrar.isChecked()){
                GuardarCredenciais(email, pass);
            } else {
                LimparCredenciais();
            }
            DataManager.LoginAPI(email, pass);

        });

    }

    private void LimparCredenciais() {
        SharedPreferences prefs =
                getSharedPreferences("APP_SETTINGS", MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("TOKEN");
        editor.remove("EMAIL");
        editor.apply();

    }

    public void GuardarCredenciais(String token, String email){
        SharedPreferences prefs =
                getSharedPreferences("APP_SETTINGS", MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("TOKEN", token);
        editor.putString("EMAIL", email);
        editor.apply();
    }

    public boolean isEmailValido(String email){
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    //Validar Pass
    public boolean isPasswordValida(String password){
        return password.length() >= 4;
    }

    @Override
    public void onValidateLogin(String token, String email) {
        if (token != null) {

            Intent intent = new Intent(this, ListaLivrosActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onError() {
        Toast.makeText(this, "Credenciais Incorretas", Toast.LENGTH_SHORT).show();

    }
}
